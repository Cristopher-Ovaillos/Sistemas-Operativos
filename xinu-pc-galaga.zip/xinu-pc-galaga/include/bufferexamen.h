#ifndef BUFFER_EXAMEN_H
#define BUFFER_EXAMEN_H

#include <xinu.h>
#define TAMANIO 10

typedef struct {
    int buffer[TAMANIO];
    uint32 index;      // Para leer
    uint32 finIndex;   // Para escribir
    sid32 semInBf;     // Semáforo para sincronización
} BufferInt;

extern BufferInt bufferInt;

void iniciar_buffer(void);
void colocar_dato(int n);
int leer_dato(void);

#endif