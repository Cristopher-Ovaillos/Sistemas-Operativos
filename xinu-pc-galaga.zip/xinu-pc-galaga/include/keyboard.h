
/*
son alias para las funciones inb y outb, que se utilizan para realizar 
operaciones de entrada/salida (I/O) en puertos especificos.
*/
#define inportb(p)      inb(p)
#define outportb(p,v)   outb(p,v)

#define KEYBOARD_DATAREG 0x60  // :Data Register(Read\Write)

#define KEYBOARD_CMDREG 0x64   // :Command Register(Read\Write)
#define BUFFER_SIZE 10 //Size of keyboard buffer

extern unsigned char kblayout [128];  // { ... } Fill your layout yourself 

