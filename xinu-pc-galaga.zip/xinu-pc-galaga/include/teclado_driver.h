#ifndef TECLADO_DRIVER_H
#define TECLADO_DRIVER_H

#include <xinu.h>

#define TAMANIO 10

typedef struct {
    unsigned char buffer[TAMANIO];
    uint32 index;
    uint32 finIndex;
    sid32 semInBf;
} StBuffer;

extern StBuffer stbuffer;
extern sid32 semKbd;
extern pid32 pidKbd;

void teclado_driver_init(void);
unsigned char teclado_driver_getc(void);
void teclado_driver_put_scancode(unsigned char sc);
void teclado_driver_open(void);
void teclado_driver_close(void);

#endif // TECLADO_DRIVER_H