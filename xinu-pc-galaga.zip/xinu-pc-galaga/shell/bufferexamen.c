#include "bufferexamen.h"

BufferInt bufferInt;

void iniciar_buffer(void) {
    bufferInt.semInBf = semcreate(0);
    bufferInt.index = 0;
    bufferInt.finIndex = 0;
}

void colocar_dato(int n) {
    // Espera hasta que haya lugar (buffer no lleno)
    while ((bufferInt.finIndex + 1) % TAMANIO == bufferInt.index) {
        // Espera activa (ocupada), puedes poner sleepms(1) para evitar bucle apretado
        sleepms(1);
    }
    bufferInt.buffer[bufferInt.finIndex] = n;
    bufferInt.finIndex = (bufferInt.finIndex + 1) % TAMANIO;
    signal(bufferInt.semInBf); // Nuevo dato disponible
}

int leer_dato(void) {
    wait(bufferInt.semInBf); // Espera a que haya un dato disponible
    int n = bufferInt.buffer[bufferInt.index];
    bufferInt.index = (bufferInt.index + 1) % TAMANIO;
    return n;
}