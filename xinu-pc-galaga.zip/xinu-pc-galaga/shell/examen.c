//#include <xinu.h>
#include "bufferexamen.h"

void productor(int pidE) {
    int i;
    for (i = 1; i <= 100; i++) {
        colocar_dato(i);
        sleepms(100); // Puedes bajar el tiempo si quieres que sea más rápido
    }
    // Avisar que terminó
    send(pidE, 0);
}

void consumidor(void) {
    int valor;
    while (1) {
        valor = leer_dato();
        printf("Valor consumido %d \n", valor);
        if (valor == 100) break; // Termina al consumir el 100
    }
}

void examen(void) {
    int pid, proc2, proc3, msj;
    iniciar_buffer();
    pid = getpid();
    proc2 = create(productor, 8192, 20, "Productor", 1, pid);
    proc3 = create(consumidor, 8192, 20, "Consumidor", 0);
    resume(proc2);
    resume(proc3);
    msj = receive();
    sleepms(1000);
    kill(proc2);
    kill(proc3);
}