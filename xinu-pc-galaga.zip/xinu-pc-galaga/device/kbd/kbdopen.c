/* kbdopen.c  -  kbdopen */

//#include <xinu.h>
#include <keyboard.h>
#include "teclado_driver.h"

devcall	kbdopen (
	 struct	dentry	*devptr,	
	 char	*name,		
	 char	*mode			
	)
{

	   teclado_driver_open();
    return OK;
	
}
