//#include <xinu.h>
#include <keyboard.h>
#include "teclado_driver.h"

unsigned char kblayout[128];

void keyboard_wait(byte a_type) {
    int _time_out = 100000;
    if (a_type == 0) {
        while(_time_out--) {
            if((inportb(0x64) & 1) == 1) return;
        }
    } else {
        while(_time_out--) {
            if((inportb(0x64) & 2) == 0) return;
        }
    }
}
devcall kbdinit(struct dentry *devptr) {
    teclado_driver_init();

    for (int i = 0; i < 128; i++) kblayout[i] = i;
    byte _status;
    keyboard_wait(1);
    outportb(0x64, 0xAE);
    keyboard_wait(1);
    outportb(0x64, 0x20);
    keyboard_wait(0);
    _status = (inportb(0x60) | 1);
    keyboard_wait(1);
    outportb(0x64, 0x60);
    keyboard_wait(1);
    outportb(0x60, _status);
    while ((inportb(0x64) & 2) != 0) inportb(0x60);

    set_evec(1 + IRQBASE, (uint32)kbdhandlerirq);
    return OK;
}