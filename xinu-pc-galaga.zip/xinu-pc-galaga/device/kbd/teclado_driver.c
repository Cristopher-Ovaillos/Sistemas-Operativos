#include <xinu.h>
#include "teclado_driver.h"

StBuffer stbuffer;
sid32 semKbd;
pid32 pidKbd;

void teclado_driver_init(void) {
    semKbd = semcreate(1);
    pidKbd = -1;
    stbuffer.semInBf = semcreate(0);
    stbuffer.index = 0;
    stbuffer.finIndex = 0;
}

unsigned char teclado_driver_getc(void) {
    unsigned char c = SYSERR;
    if (pidKbd == getpid()) {
        wait(stbuffer.semInBf);
        c = stbuffer.buffer[stbuffer.index];
        stbuffer.buffer[stbuffer.index] = 0;
        stbuffer.index = (stbuffer.index + 1) % TAMANIO;
    }
    return c;
}

void teclado_driver_put_scancode(unsigned char sc) {
    if ((stbuffer.finIndex + 1) % TAMANIO != stbuffer.index) {
        stbuffer.buffer[stbuffer.finIndex] = sc;
        stbuffer.finIndex = (stbuffer.finIndex + 1) % TAMANIO;
        signal(stbuffer.semInBf);
    }
}

void teclado_driver_open(void) {
    wait(semKbd);
    pidKbd = getpid();
}

void teclado_driver_close(void) {
    if (pidKbd == getpid()) {
        signal(semKbd);
    }
}