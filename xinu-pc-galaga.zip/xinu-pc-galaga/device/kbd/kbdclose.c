/* kbdclose.c  -  kbdclose */

//#include <xinu.h>
//incluir keyboard
#include <keyboard.h>
#include "teclado_driver.h"
/*------------------------------------------------------------------------
 * kbdclose  -  Close the keyboard device
 *------------------------------------------------------------------------
 */

//estos es estan definidos desde keyboard e inicializados en KBDINIT


devcall	kbdclose (
	  struct dentry	*devptr		// Entry in device switch table	
	)
{
  teclado_driver_close();
    return OK;
}


