#include "teclado_driver.h"

unsigned char kbdgetc(void) {
    return teclado_driver_getc();
}