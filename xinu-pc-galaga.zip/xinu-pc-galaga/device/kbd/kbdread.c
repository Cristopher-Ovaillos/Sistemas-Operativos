/* kbdread.c  -  kbdread */


//#include <xinu.h>
#include <mouse.h>
#include "teclado_driver.h"
devcall	kbdread (
	  struct dentry	*devptr,	
	  char          *buffer,     
          uint32        count         
	)
{
      buffer[0] = kbdgetc();
    return OK;
}


